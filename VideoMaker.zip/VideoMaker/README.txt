before using run:

pip install moviepy
pip install pillow
pip install numpy

place .mp4 file in this folder

after video is ready send "sendable" folder to ev3 along with "videoPlayer.py"