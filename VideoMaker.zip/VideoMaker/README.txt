before using run in a terminal:

pip install moviepy
pip install pillow
pip install numpy
pip install playsound3

after video is ready send "sendable" folder to ev3 along with "videoPlayer.py"