#!/usr/bin/env python3
from ev3dev2.sound import Sound
from ev3dev2.display import Display
from PIL import ImageDraw
from PIL import Image
import time
import os


halfRes = False

fps = 10




disp = Display()
draw = ImageDraw.Draw(disp.image)
path = "soundcuts/"
sound = Sound()
sound.set_volume(100)

sheet = Image.open(os.path.join(path, "sheet.bmp"))
sheet.load()
height = 64 if halfRes else 128
width = 89 if halfRes else 178
frames = sheet.size[1] // height
start_time = time.time()
sound.play_file(os.path.join(path, "song.wav"),play_type=1)


for i in range(1, frames):
    target_time = start_time + (i / fps)
    current_time = time.time()

    if current_time > target_time + (1 / fps):
        continue

    box = (0, i * height, width, (i + 1) * height)
    img = sheet.crop(box)
    if halfRes:
        img = img.resize((178, 128), resample=Image.Resampling.NEAREST)
    disp.image.paste(img, (0, 0))
    disp.update()
    time.sleep(1 / fps)
time.sleep(1)