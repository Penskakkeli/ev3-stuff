#!/usr/bin/env python3
from ev3dev2.sound import Sound
from ev3dev2.display import Display
from ev3dev2.button import Button
from ev3dev2.fonts import load as loadfont
from PIL import ImageDraw
from PIL import Image
import time
import os
import subprocess



fps = 10 # is automatically set from the info file anyway this is just a placeholder
halfRes = False # this too

btn = Button()
disp = Display()
draw = ImageDraw.Draw(disp.image)
path = "videos/"
sound = Sound()
sound.set_volume(100)
font = loadfont("luBS10")
bigfont = loadfont("luBS24")
current_vol = 100
last_vol_change = 0
def play():
    global path,halfRes,fps,sound,draw,disp,bigfont,last_vol_change,current_vol
    sheet = Image.open(os.path.join(path, "sheet.bmp"))
    sheet.load()

    height = 64 if halfRes else 128
    width = 89 if halfRes else 178
    frames = sheet.size[1] // height


    aud = subprocess.Popen(["aplay", "-q", os.path.join(path, "sound.wav")])
    while True:
        if aud.poll() is not None:
            break
        try:
            with open("/proc/asound/card0/pcm0p/sub0/status", "r") as f:
                status = f.read()
                if "closed" not in status:
                    break
        except FileNotFoundError:
            time.sleep(0.3)
            break
            
        time.sleep(0.05)
    start_time = time.time()
    for i in range(0, frames):
        target_time = start_time + (i / fps)
        current_time = time.time()

        if current_time > target_time + (1 / fps):
            continue
        if btn.enter:
            disp.text_pixels("Loading...",x=10,y=64,font=bigfont,clear_screen=True)
            disp.update()
            aud.kill()
            break
        if btn.up or btn.down:
            if current_time - last_vol_change > 0.2:
                if btn.up:
                    current_vol = min(current_vol + 5, 100)
                elif btn.down:
                    current_vol = max(current_vol - 5, 0)
                
                
                komento = "amixer -q sset PCM " + str(current_vol) + "%"
                
                
                subprocess.Popen(komento, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                
                last_vol_change = current_time
        box = (0, i * height, width, (i + 1) * height)
        img = sheet.crop(box)
        if halfRes:
            img = img.resize((178, 128), resample=Image.Resampling.NEAREST)
        disp.image.paste(img, (0, 0))
        disp.update()
        timenow = time.time()
        next_target = start_time + ((i + 1) / fps)
        remainingtime = next_target - timenow
        
        if remainingtime > 0:
            time.sleep(remainingtime)
            
    time.sleep(1)
def loadlist():
    global fps,halfRes,path,bigfont,font
    
    selected = False
    
    cursorPos = 0 
    def drawui(files):
        disp.clear()
        y = 0
        for obj in files:
            disp.text_pixels(obj[0]+"   "+obj[1]+"FPS",x=10,y=16 * (y-cursorPos) + 64,font=font,clear_screen=False)
            if cursorPos == y:
                disp.draw.bitmap([120,20],bitmap=obj[4])
            y += 1
        disp.text_pixels("> ",x=1,y=64,font=font,clear_screen=False)
        disp.update()
    drawui(shownfiles)
    while selected == False:
        moved = False
        if btn.down or btn.right:
            cursorPos += 1
            moved = True
        if btn.up or btn.left:
            cursorPos -= 1
            moved = True
        if cursorPos < 0:
            cursorPos = 0
        if cursorPos > len(shownfiles)-1:
            cursorPos = len(shownfiles)-1
        if btn.enter:
            selected = shownfiles[cursorPos]
        if moved:
            drawui(shownfiles)
            time.sleep(0.2)
        else:
            time.sleep(0.02)
    disp.text_pixels("Loading...",x=10,y=64,font=bigfont,clear_screen=True)
    disp.update()
    path = "videos/"+selected[3]+"/"
    fps = int(selected[1])
    halfRes = selected[2] == "True"
    play()
shownfiles = []
filelist = os.listdir(path)
for vfile in filelist:
    info = open("videos/"+vfile+"/info.txt",encoding="utf-8",mode="r").read().splitlines()
    name = vfile
    if len(name) > 10:
        name = name[:10]+"..."
    vidsub = [name,info[0],info[1],vfile,Image.open("videos/"+vfile+"/thumb.bmp")]
    shownfiles.append(vidsub)
while True:
    loadlist()    
