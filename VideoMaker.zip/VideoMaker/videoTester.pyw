#!/usr/bin/env python3
from PIL import ImageDraw
from PIL import Image, ImageTk
from tkinter.filedialog import askdirectory
import time
import os
import tkinter as tk
from playsound3 import playsound
halfRes = False

fps = 10

script_dir = os.path.dirname(os.path.abspath(__file__))

window = tk.Tk()
window.title("video player")
window.geometry("356x286")
window.minsize(width=178,height=158)
dispImg = ImageTk.PhotoImage(Image.new(mode="RGB",size=(178, 128)), master=window)
port = tk.Label(window,image=dispImg)
port.place(x=0,y=0)
def clamp(value, min_val, max_val):
    return max(min_val, min(value, max_val))
def aspFix():
    sizeX = clamp(window.winfo_width(),1,100000)
    window.geometry(f"{sizeX}x{int(sizeX * (128 / 178) + 30)}")



aspFixButt = tk.Button(text="Fix aspect ratio",command=lambda:aspFix())
aspFixButt.place(x=30,y=276,width=100,height=30)
path = os.path.join(script_dir, "sendable", "videos")

path = askdirectory()

sheet = Image.open(os.path.join(path, "sheet.bmp"))
sheet.load()

height = 64 if halfRes else 128
width = 89 if halfRes else 178
frames = sheet.size[1] // height

def showImage(img):
    global dispImg
    dispImg = ImageTk.PhotoImage(img)
    port.config(image=dispImg)

start_time = time.time()
playsound(os.path.join(path, "sound.wav"), block=False)
for i in range(0, frames):
    target_time = start_time + (i / fps)
    current_time = time.time()

    if current_time > target_time + (1 / fps):
        continue

    box = (0, i * height, width, (i + 1) * height)
    img = sheet.crop(box)
    wsizeX = clamp(window.winfo_width(),1,10000)
    wsizeY = clamp(window.winfo_height() - 30,1,10000)
    img = img.resize((wsizeX, wsizeY), resample=Image.Resampling.NEAREST)
    aspFixButt.place(x=30, y=wsizeY, width=wsizeX - 60, height=30)
    window.title("video player " + str(window.winfo_width()) + " x " + str(window.winfo_height() - 30))
    showImage(img)
    window.update()
    timenow = time.time()
    next_target = start_time + ((i + 1) / fps)
    remainingtime = next_target - timenow
    
    if remainingtime > 0:
        time.sleep(remainingtime)

time.sleep(1)

window.destroy()
window.mainloop()
