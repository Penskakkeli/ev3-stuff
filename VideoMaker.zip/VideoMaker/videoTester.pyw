#!/usr/bin/env python3
from PIL import ImageDraw
from PIL import Image, ImageTk
import time
import os
import tkinter as tk
from playsound3 import playsound
halfRes = False

fps = 10

script_dir = os.path.dirname(os.path.abspath(__file__))

window = tk.Tk()
window.title("video player")
window.geometry("178x128")

dispImg = ImageTk.PhotoImage(Image.new(mode="RGB",size=(178, 128)), master=window)
port = tk.Label(window,image=dispImg)
port.pack()

path = os.path.join(script_dir, "sendable", "soundcuts")


sheet = Image.open(os.path.join(path, "sheet.bmp"))
sheet.load()

height = 64 if halfRes else 128
width = 89 if halfRes else 178
frames = sheet.size[1] // height

def showImage(img):
    global dispImg
    dispImg = ImageTk.PhotoImage(img)
    port.config(image=dispImg)

start_time = time.time()
playsound(os.path.join(path, "song.wav"), block=False)
for i in range(0, frames):
    target_time = start_time + (i / fps)
    current_time = time.time()

    if current_time > target_time + (1 / fps):
        continue

    box = (0, i * height, width, (i + 1) * height)
    img = sheet.crop(box)
    if halfRes:
        img = img.resize((178, 128), resample=Image.Resampling.NEAREST)
    showImage(img)
    window.update()
    timenow = time.time()
    next_target = start_time + ((i + 1) / fps)
    remainingtime = next_target - timenow
    
    if remainingtime > 0:
        time.sleep(remainingtime)

time.sleep(1)
window.destroy()
window.mainloop()
