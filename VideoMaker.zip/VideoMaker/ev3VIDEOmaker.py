import moviepy as mp
from moviepy import vfx, VideoFileClip
import numpy as np
from PIL import Image
from pathlib import Path
import os
Fpath = Path(__file__).parent
vid = mp.VideoFileClip(Fpath / "video.mp4")


halfRes = False

fps = 10

split = False
segName = "piece"


parts = 0

if halfRes:
    vid = vid.resized((89, 64)).with_effects([vfx.BlackAndWhite()])
else:
    vid = vid.resized((178, 128)).with_effects([vfx.BlackAndWhite()])
w, h = vid.size

def bw(Oframe, ti):
    frame = Oframe(ti)
    gray = np.mean(frame, axis=2)
    tres = 120
    mask = gray > tres
    newF = np.zeros_like(frame)
    newF[mask] = 255
    return newF


vid = vid.transform(bw)
os.makedirs("soundcuts", exist_ok=True)
frames = []
duration = vid.duration
steps = int(duration * fps)
print("video...")
for step in range(steps):
    t = step / fps
    if t >= duration:
        break
        
    frame = vid.get_frame(t)
    img = Image.fromarray(frame.astype('uint8')).convert('1')
    frames.append(img)

height = h * len(frames)
sheet = Image.new('1', (w, height))
for i, frame in enumerate(frames):
    sheet.paste(frame, (0, i * h))

sheet.save("soundcuts/sheet.bmp")
print("audio...")
vid.audio.write_audiofile("soundcuts/song.wav", fps=11025,nbytes=2,buffersize=2000,codec="pcm_s16le",ffmpeg_params=["-ac", "1"])
print("done")