import moviepy as mp
from moviepy import vfx, VideoFileClip
import numpy as np
from PIL import Image, ImageFilter
from pathlib import Path
import os
import time
Fpath = os.path.dirname(os.path.abspath(__file__))
vid = ""
if os.path.exists(os.path.join(Fpath, "video.mp4")) == False:
    print("No video.mp4!, press enter")
    input()
    quit
else:
    vid = mp.VideoFileClip(os.path.join(Fpath, "video.mp4"))
halfRes = False

edgeDetection = True

fps = 10

split = False
segName = "piece"


parts = 0

if halfRes:
    vid = vid.resized((89, 64)).with_effects([vfx.BlackAndWhite()])
else:
    vid = vid.resized((178, 128)).with_effects([vfx.BlackAndWhite()])
w, h = vid.size

def bw(Findframe, ti):
    frame = Findframe(ti)
    tres = 120
    if edgeDetection:
        pilimg = Image.fromarray(frame)
        pilimg = pilimg.filter(ImageFilter.FIND_EDGES)
        frame = np.array(pilimg)
        tres = 30
    gray = np.mean(frame, axis=2)
    mask = gray > tres
    newF = np.zeros_like(frame)
    newF[mask] = 255
    return newF


vid = vid.transform(bw)
os.makedirs(os.path.join(Fpath, "sendable", "soundcuts"), exist_ok=True)
frames = []
duration = vid.duration
steps = int(duration * fps)
print("video...")
for step in range(steps):
    t = step / fps
    if t >= duration:
        break
        
    frame = vid.get_frame(t)
    img = Image.fromarray(frame.astype('uint8')).convert('1')
    frames.append(img)

height = h * len(frames)
sheet = Image.new('1', (w, height))
for i, frame in enumerate(frames):
    
    sheet.paste(frame, (0, i * h))

sheet.save(os.path.join(Fpath, "sendable", "soundcuts","sheet.bmp"))
print("audio...")
vid.audio.write_audiofile(os.path.join(Fpath, "sendable", "soundcuts","song.wav"), fps=11025,nbytes=2,buffersize=2000,codec="pcm_s16le",ffmpeg_params=["-ac", "1"])
print("done")
time.sleep(1)
