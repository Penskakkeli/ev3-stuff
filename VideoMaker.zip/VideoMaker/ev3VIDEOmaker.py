import moviepy as mp
from moviepy import vfx
import numpy as np
from PIL import Image, ImageFilter
from tkinter.filedialog import askopenfilename
import os
import time
Fpath = os.path.dirname(os.path.abspath(__file__))
vid = ""
fp2 = "noyoudonthavethisfile123456789.mp4"
while os.path.exists(fp2) == False:
    print("choose video file!")
    fp2 = askopenfilename()
vid = mp.VideoFileClip(fp2)
videoName = fp2.split("/")
videoName = videoName[len(videoName)-1]
videoName = videoName[:len(videoName)-3]
#--------options--------
halfRes = False
edgeDetection = False
dither = True
# edge and dither cant be used at the same time
fps = 10


if halfRes:
    vid = vid.resized((89, 64)).with_effects([vfx.BlackAndWhite()])
else:
    vid = vid.resized((178, 128)).with_effects([vfx.BlackAndWhite()])
w, h = vid.size

def bw(Findframe, ti):
    frame = Findframe(ti)
    tres = 120
    if edgeDetection:
        pilimg = Image.fromarray(frame)
        pilimg = pilimg.filter(ImageFilter.FIND_EDGES)
        frame = np.array(pilimg)
        tres = 30
    elif dither:
        frame = Image.fromarray(frame).convert("1", dither=Image.Dither.FLOYDSTEINBERG)
        return (np.array(frame) * 255).astype(np.uint8)
    newF = frame
    gray = np.mean(frame, axis=2)
    mask = gray > tres
    newF = np.zeros_like(frame)
    newF[mask] = 255
    return newF

print("starting...")
vid = vid.transform(bw)
os.makedirs(os.path.join(Fpath, "sendable", "videos",videoName), exist_ok=True)
frames = []
duration = vid.duration
steps = int(duration * fps)

print("video...")
for step in range(steps):
    t = step / fps
    if t >= duration:
        break
        
    frame = vid.get_frame(t)
    img = Image.fromarray(frame.astype('uint8')).convert('1')
    frames.append(img)

height = h * len(frames)
sheet = Image.new('1', (w, height))
for i, frame in enumerate(frames):
    
    sheet.paste(frame, (0, i * h))
def roundToFrame(val,halfRes):
    rby = 0
    if halfRes: rby = 64 
    else: rby=128
    val /= rby 
    val = round(val)
    val *= rby
    return val

framey = roundToFrame(sheet.size[1] // 2,halfRes)
thumb = sheet.crop([0,framey,sheet.size[0],framey + h])
thumb = thumb.resize([60,40])
thumb.save(os.path.join(Fpath, "sendable", "videos",videoName,"thumb.bmp"))
sheet.save(os.path.join(Fpath, "sendable", "videos",videoName,"sheet.bmp"))
info = f"{fps}\n{halfRes}"
infofile = open(os.path.join(Fpath, "sendable", "videos",videoName,"info.txt"),"w",encoding="utf-8",)
infofile.write(info)
print("audio...")
vid.audio.write_audiofile(os.path.join(Fpath, "sendable", "videos",videoName,"sound.wav"), fps=11025,nbytes=2,buffersize=2000,codec="pcm_s16le",ffmpeg_params=["-ac", "1"])
print("done")
time.sleep(1)
